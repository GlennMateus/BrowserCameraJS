export default teste = () => {
    return ('hello world');
}