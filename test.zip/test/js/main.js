import teste from 'teste'

window.onload(
    function(){
        alert(teste);
    }
)